Attached in this archive is the latest build of the kb.exe program: 35,396 for King's Bounty - The Legend. This is the build that I use with the game that I acquired from Gamer's Gate. For some reason beyond me, other digital distributions of the game do not include the latest build, but rather build 35,234. As an example, I also own a digital copy of the game from Good Ol' Games (GOG) and the build is the aforementioned 35,234. Both of these builds are for V1.7 of the game, and to my knowledge these are the only two V1.7 kb.exe game builds.

I develop a mod for King's Bounty - The Legend, Heroes of Might and Magic 3 Babies, and it does not work properly with builds older than 35,396. My mod in particular uses certain features that require the latest build in order to work. I investigated this matter due to reports of issues with my mod and the older 35,234 build and discovered that build 35,234 has bugs in it that build 35,396 fixes. For example, the Game.LocType function in Build 35,234 is bugged and causes an error everytime you try to use that function in LUA code. I have bonuses / penalties that require this function to work properly in order to implement these features. There are other issues as well (for example I've added damage hints for all the Spirit abilities and some of these do not work in Build 35,234).

Because I feel that the digital distributors have dropped the ball here, I'm providing Build 35,396 kb.exe in this archive so that people can play the latest build of the game as well as enjoy my mod properly. This also avoids the headache of developing for separate builds, which I should not have to do.

I've tried Build 35,396 kb.exe with my version of the GOG King's Bounty - The Legend version, which happens to be build 35,234. Everything seems to work okay, as far as I can tell so good luck in getting this to work for you.

Note that this is not an official patch and is not affiliated in anyway with the developers / distributors, etc. of the King's Bounty - The Legend game. You use this at your own risk, but I sincerely hope that it will provide you more enjoyment for the game that you've purchased.

Notes:

1. By using the kb.exe Build 35,396 included in this archive, it creates save games that older builds of the game will not display or load from the Load Save Game menu option.
2. If you play Build 35,396, you won't be able to go back to a previous build with games saved under this build.
3. Older save games are not affected, just new ones generated with the build of the game with which they are played.
4. Build 35,396 has had no issues with loading older save games that I've noticed, but if in doubt, you should start a new game.

Requirements:

1. You must have Patch V1.7 of the game installed on your computer.

Installation instructions:

1. Before doing anything, launch King's Bounty - The Legend and determine your build number.
   a. The build number is located in the lower left of the Main Menu screen.
   b. If you have Build 35,396 then there is nothing to do and you already have the latest build.
   c. If you have Build 35,234 then you have an older build of the game - proceed to step 2.
   d. If you have a build different than the above (I have only seen the two above builds) then using the kb.exe in this archive may cause problems - use at your own risk!
2. Find the folder where your King's Bounty kb.exe is installed
   a. Note that for me, kb.exe was installed in C:\GOG Games\King's Bounty and is build 35,234.
   b. Rename kb.exe to kb.exe.old (or something similar).
   c. Extract kb.exe from this archive and place it in the same folder where you renamed kb.exe above.
   d. Launch the game and enjoy! Note that you should now see Build 35,396 in the lower left. If you do not see this, then you've done something wrong. Re-read these instructions and try again.

Uninstallation instructions:

1. Delete kb.exe from the King's Bounty - The Legend installation folder. See 2a above for an example of where the game was installed on my system.
2. Rename your backup file for the previous build (for example, I called the backup file kb.exe.old) to kb.exe.
3. Note that any save games created with the newer build will not be listed in the save game list when attempting to load a save game with an older build. You should either move these save game files or delete them if they are now longer needed.

Here is some relevant information regarding the kb.exe included in this archive:

1. Size: 13,045,688
2. Digital Signature:
   a. Name of Signer: 1C-SoftClub LLC
   b. Digest Algorithm: sha1
   c. Timestamp: Monday, November 14, 2011 10:55:51 PM

If you have any issues regarding the installed build of your King's Bounty - The Legend game, I encourage you to utilize the proper support channels for your game supplier.

Enjoy!

Matt Caspermeyer