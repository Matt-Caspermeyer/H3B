-- New! For generating the amount of dragonfly wings you have
function gen_dragonfly_wings()
  local count = Logic.hero_lu_item( "wing_dragonfly", "count" )

  return tostring( count )
end

-- New! Hint generator for all items (relies on ITEMS.TXT being included in CONFIG.TXT)
function gen_item_bonus_fight_hint()
  local ally_color = "<color=134,220,250>"
  local enemy_color = "<color=255,140,140>"
  local unit_color = "<color=240,168,4>"
  local level_color = "<color=191,95,255>"
  local loctype_color = "<color=0,134,139>"
  local daytime_color = "<color=243,107,8>"
  local race_color = "<color=217,217,25>"
  local skill_color = "<color=0,187,232>"
  local spell_color = "<color=0,187,232>"
  local spirit_color = "<color=243,107,8>"
  local effect_color = "<color=255,204,17>"
  local pos_color = "<color=55,188,97>"
  local neg_color = "<color=255,100,100>"
  local mod_color = "<color=145,248,117>"
  local tc = "</color>"
  local name = Obj.name()
  local text = ""
  local name_fight = name .. "/fight"
  local fight_filter_list = { "belligerent", "race", "unit", "level", "daytime", "loctype" }
  local fight_mod_list = { "dbonus", "pbonus", "rbonus" }
  local fight_bonus_table = {}

  local function parse_bonus_text( mod_type, bonus_text, last_value, last_value_type )
    local text = ""
    local bonus_type = text_dec( bonus_text, 1 )
    local morale_label = ""
    local save_value
    local save_type
    local bonus_list_table = { "type", "abs", "base", "current", "duration", "dod", "priority" }

    if bonus_type == "hitback" then
      return pos_color .. "<label=fight_bonus_mod_hitback>" .. tc
    else
      for i = 2, text_par_count( bonus_text ) do
        local value = tonum( text_dec( bonus_text, i ) )
  
        if value ~= 0 then
          if i < 5 then
            save_type = bonus_list_table[ i ]

            if value > 0 then
              if value == last_value
              and save_type == last_value_type then
                text = text .. pos_color
              else
                text = text .. pos_color .. "+" .. tostring( value )
              end

              if bonus_type == "moral" then
                morale_label = "_p" .. tostring( value )
              end
            else
              if value == last_value
              and save_type == last_value_type then
                text = text .. neg_color
              else
                text = text .. neg_color .. tostring( value )
              end

              if bonus_type == "moral" then
                morale_label = "_n" .. tostring( math.abs( value ) )
              end
            end
    
            if i == 3
            or i == 4 then
              if not ( value == last_value
              and save_type == last_value_type ) then
                text = text .. "%" .. "<label=fight_bonus_mod_" .. tostring( i ) .. ">"
              end
            end

            save_value = value
          elseif i == 5
          and value ~= -100 then
            text = text .. "<label=fight_bonus_mod_for>" .. value
    
            if value == 1 then
              text = text .. "<label=fight_bonus_mod_round1>"
            else
              text = text .. "<label=fight_bonus_mod_round2>"
            end
          elseif i == 6
          and value ~= 0 then
            text = text .. "<label=fight_bonus_mod_until>"
          end
        end
      end
    end

    if fight_bonus_table [ bonus_type ] then
      if bonus_type == "cold"
      or bonus_type == "fire"
      or bonus_type == "magic"
      or bonus_type == "physical"
      or bonus_type == "poison" then
        text = text .. " <image=itm_dmg_" .. bonus_type .. morale_label .. ".png>"
      else
        text = text .. " <image=itm_" .. bonus_type .. morale_label .. ".png>"
      end
    else
      text = text .. "<label=fight_bonus_mod_" .. bonus_type .. morale_label .. ">"
    end

    if mod_type == "dbonus"
    or mod_type == "rbonus" then
      text = text .. "<label=fight_bonus_mod_" .. mod_type .. ">"
    end

    text = text .. tc

    fight_bonus_table[ bonus_type ] = true

    return text, save_value, save_type, save_value == last_value
  end

  local fight_number
  local total_filter_count = 0
  local last_text2, last_belligerent, last_race, last_unit, last_level, last_loctype
  local last_belligerent_same = false
  local last_race_same = false
  local last_unit_same = false
  local last_level_same = false
  local last_loctype_same = false
  local last_value = 1e10
  local last_value_type
  local last_value_same = false

  while true do
    local text2, bonus_text = "", ""
    local filter_race, filter_unit = false, false

    if fight_number == nil then
      fight_number = ""
    elseif fight_number == "" then
      fight_number = tostring( 1 )
    else
      fight_number = tostring( tonumber( fight_number ) + 1 )
    end

    for i = 1, table.getn( fight_filter_list ) do
      local filter_type = fight_filter_list[ i ]
      local filter_desc = Game.Config( name_fight .. "/" .. fight_number .. "/filter/" .. filter_type )

      if filter_desc ~= nil
      and filter_desc ~= "" then
        if filter_type == "belligerent" then
          if filter_desc == last_belligerent then
            last_belligerent_same = true
          else
            last_belligerent_same = false
            last_value = 1e10
          end

          if text2 ~= "" then
            text2 = text2 .. " "
          end

          if filter_desc == "ally" then
            text2 = text2 .. ally_color .. "<label=fight_bonus_filter_" .. filter_type .. "_" .. filter_desc .. ">" .. tc
          else
            text2 = text2 .. enemy_color .. "<label=fight_bonus_filter_" .. filter_type .. "_" .. filter_desc .. ">" .. tc
          end

          last_belligerent = filter_desc
        elseif filter_type == "daytime" then
          if text2 ~= "" then
            text2 = text2 .. " "
          end

          text2 = text2 .. "<label=fight_bonus_filter_" .. filter_type .. ">"
          local text3 = ""

          for j = 1, text_par_count( filter_desc ) do
            local daynumber

            if j > 1 then
              if text_par_count( filter_desc ) == 2 then
                text3 = text3 .. " and "
              elseif j == text_par_count( filter_desc ) then
                text3 = text3 .. ", and "
              else
                text3 = text3 .. ", "
              end
            end

            local daytime = text_dec( filter_desc, j )

            if daytime == "morning" then
              daynumber = "0"
            elseif daytime == "day" then
              daynumber = "1"
            elseif daytime == "evening" then
              daynumber = "2"
            elseif daytime == "night" then
              daynumber = "3"
            end

            text3 = text3 .. "<label=int_time_" .. daynumber .. ">"
          end

          text2 = daytime_color .. text2 .. " " .. text3 .. tc
        elseif filter_type == "level" then
          if filter_desc == last_level then
            last_level_same = true
          else
            last_level_same = false
            last_value = 1e10
          end

          if text2 ~= "" then
            text2 = text2 .. " "
          end

          text2 = text2 .. level_color .. "<label=fight_bonus_filter_" .. filter_type .. ">"
          
          if string.find( filter_desc, "," ) then
            text2 = text2 .. " " .. text_dec( filter_desc, 1 ) .. "-" .. text_dec( filter_desc, text_par_count( filter_desc ) )
          elseif string.find( filter_desc, "<" )
          or string.find( filter_desc, ">" ) then
            local token = ""
            local label = ""

            if string.find( filter_desc, "<=" ) then
              token = "<="
              label = "<label=fight_bonus_filter_level_less_than_or_equal>"
            elseif string.find( filter_desc, "<" ) then
              token = "<"
              label = "<label=fight_bonus_filter_level_less_than>"
            elseif string.find( filter_desc, ">=" ) then
              token = ">="
              label = "<label=fight_bonus_filter_level_greater_than_or_equal>"
            elseif string.find( filter_desc, ">" ) then
              token = ">"
              label = "<label=fight_bonus_filter_level_greater_than>"
            end

            text2 = text2 .. " " .. label .. " " .. string.sub( filter_desc, string.len( token ) + 1 )
          else
            text2 = text2 .. " " .. filter_desc
          end

          text2 = text2 .. tc
          last_level = filter_desc
        elseif filter_type == "loctype" then
          if filter_desc == last_loctype
          and last_belligerent_same then
            last_loctype_same = true
            text2 = ""
          else
            last_loctype_same = false
            last_value = 1e10

            if text2 ~= "" then
              text2 = text2 .. " "
            end
  
            text2 = text2 .. loctype_color .. "(<label=fight_bonus_filter_" .. filter_type .. "> "
            local text3 = ""
  
            for j = 1, text_par_count( filter_desc ) do
              if j > 1 then
                if text_par_count( filter_desc ) == 2 then
                  text3 = text3 .. " and "
                elseif j == text_par_count( filter_desc ) then
                  text3 = text3 .. ", and "
                else
                  text3 = text3 .. ", "
                end
              end
  
              text3 = text3 .. "<label=fight_bonus_filter_loc_" .. text_dec( filter_desc, j ) .. ">"
            end
  
            text2 = text2 .. text3 .. ")" .. tc
            last_loctype = filter_desc
          end
        elseif filter_type == "race" then
          filter_race = true

          if filter_desc == last_race
          and last_belligerent_same then
            last_race_same = true
            text2 = ""
          else
            last_race_same = false
            last_value = 1e10

            if text2 ~= "" then
              text2 = text2 .. " "
            end
  
            local text3 = ""
  
            for j = 1, text_par_count( filter_desc ) do
              if j > 1 then
                if text_par_count( filter_desc ) == 2 then
                  text3 = text3 .. " and "
                elseif j == text_par_count( filter_desc ) then
                  text3 = text3 .. ", and "
                else
                  text3 = text3 .. ", "
                end
              end
  
              text3 = text3 .. "<image=itm_race_" .. text_dec( filter_desc, j ) .. ".png> ".. "<label=itm_" .. text_dec( filter_desc, j ) .. ">"
            end
  
            text2 = text2 .. race_color .. text3 .. tc
            last_race = filter_desc
          end
        elseif filter_type == "unit" then
          filter_unit = true
          local ranged_troops = "alchemist,archer,archmage,beholder,beholder2,bowman,cannoner,catapult,cyclop,druid,elf,elf2,goblin,kingthorn,necromant,priest,priest2,thorn"
          local melee_troops = "archdemon,barbarian,barbarian2,bat,bat2,bear,bear_white,bear2,blackdragon,blackknight,bluedragon,bonedragon,cerberus,demon,demoness,devilfish,dragonfly_fire,dragonfly_lake,dryad,dwarf,ent,ent2,footman,footman2,ghost,ghost2,giant,goblin2,graywolf,greendragon,griffin,griffin2,griffin_spirit,horseman,hyena,imp,imp2,knight,miner,ogre,orc,orc2,peasant,pirat,pirat2,reddragon,robber,robber2,shaman,skeleton,snake,snake_green,snake_royal,spider,spider_fire,spider_undead,spider_venom,sprite,sprite_lake,thorn_warrior,unicorn,unicorn2,vampire,vampire2,werewolf,wolf,zombie,zombie2"

          if string.lower( filter_desc ) == ranged_troops then
            filter_desc = "ranged_troops"
          elseif string.lower( filter_desc ) == melee_troops then
            filter_desc = "melee_troops"
          end

          if filter_desc == last_unit then
            last_unit_same = true
          else
            last_unit_same = false
            last_value = 1e10
          end

          if text2 ~= "" then
            text2 = text2 .. " "
          end

          local text3 = ""

          for j = 1, text_par_count( filter_desc ) do
            if j > 1 then
              if text_par_count( filter_desc ) == 2 then
                text3 = text3 .. " and "
              elseif j == text_par_count( filter_desc ) then
                text3 = text3 .. ", and "
              else
                text3 = text3 .. ", "
              end
            end

            if filter_desc == "ranged_troops" then
              text3 = text3 .. "<label=fight_bonus_filter_ranged>"
            elseif filter_desc == "melee_troops" then
              text3 = text3 .. "<label=fight_bonus_filter_melee>"
            else
              text3 = text3 .. "<label=cpsn_" .. text_dec( filter_desc, j ) .. ">"
            end
          end

          text2 = text2 .. unit_color .. text3 .. tc
          last_unit = filter_desc
        end
      else
        if filter_type == "belligerent" then
          last_belligerent = filter_desc
          last_belligerent_same = false
        elseif filter_type == "race" then
          last_race = filter_desc
          last_race_same = false
        elseif filter_type == "unit" then
          last_unit = filter_desc
          last_unit_same = false
        elseif filter_type == "level" then
          last_level = filter_desc
          last_level_same = false
        elseif filter_type == "loctype" then
          last_loctype = filter_desc
          last_loctype_same = false
        end
      end
    end

    for i = 1, table.getn( fight_mod_list ) do
      local mod_type = fight_mod_list[ i ]
      local mod_desc = Game.Config( name_fight .. "/" .. fight_number .. "/" .. mod_type )

      if mod_desc ~= nil
      and mod_desc ~= "" then
        if bonus_text == "" then
          bonus_text, last_value, last_value_type, last_value_same = parse_bonus_text( mod_type, mod_desc, last_value, last_value_type )
        else
          local bonus_temp
          bonus_temp, last_value, last_value_type, last_value_same = parse_bonus_text( mod_type, mod_desc, last_value, last_value_type )

          if last_value_same then
            bonus_text = bonus_text .. " /" .. bonus_temp
          else
            bonus_text = bonus_text .. ", " .. bonus_temp
          end
        end
      end
    end

    if text2 ~= ""
    or bonus_text ~= "" then
      total_filter_count = total_filter_count + 1

      if not filter_race
      and not filter_unit
      and not last_loctype_same then
        text2 = text2 .. " <label=fight_bonus_filter_troop>"
      end

      if text2 ~= "" then
        text2 = text2 .. ": "
      end

      if text2 ~= last_text2 then
        if last_belligerent_same
        and ( last_race_same
        or last_loctype_same ) then
          text = text .. ", " .. text2 .. bonus_text
        else
          text = text .. "<br>" .. text2 .. bonus_text
        end
      elseif bonus_text ~= "" then
        if last_value_same then
          text = text .. " /" .. bonus_text
        else
          text = text .. ", " .. bonus_text
        end
      end
    end

    if fight_number ~= ""
    and text2 == ""
    and bonus_text == "" then
      break
    end

    last_text2 = text2
  end

  return text
end

-- New! Hint generator for all items (relies on ITEMS.TXT being included in CONFIG.TXT)
function gen_item_bonus_mod_hint()
  local ally_color = "<color=134,220,250>"
  local enemy_color = "<color=255,140,140>"
  local unit_color = "<color=240,168,4>"
  local level_color = "<color=243,107,8>"
  local daytime_color = "<color=243,107,8>"
  local race_color = "<color=217,217,25>"
  local skill_color = "<color=0,187,232>"
  local spell_color = "<color=0,187,232>"
  local spirit_color = "<color=243,107,8>"
  local effect_color = "<color=255,204,17>"
  local pos_color = "<color=55,188,97>"
  local neg_color = "<color=255,100,100>"
  local mod_color = "<color=145,248,117>"
  local tc = "</color>"
  local name = Obj.name()
  local text = ""
  local name_mod = name .. "/mods"
  local mod_list = { "attack",
                     "booksize",
                     "defense",
                     "leadership",
                     "intellect",
                     "mana",
                     "rage",
                     "sp_add_ap_ogre_rage",
                     "sp_add_ap_run",
                     "sp_add_burn_firepower",
                     "sp_add_burn_fire_shot",
                     "sp_add_burn_firethrow",
                     "sp_add_burn_rail",
                     "sp_add_burn_throw2",
                     "sp_add_damage_bless",
                     "sp_add_damage_weakness",
                     "sp_add_dragonslayer_krugom",
                     "sp_add_freeze_throw3",
                     "sp_add_heal_cast_sacrifice",
                     "sp_add_heal_cure",
                     "sp_add_heal_respawn",
                     "sp_add_health_ice_totem",
                     "sp_add_health_protective_totem",
                     "sp_add_holy_throw3",
                     "sp_add_HP_rooted",
                     "sp_add_infliction_burn",
                     "sp_add_infliction_freeze",
                     "sp_add_infliction_poison",
                     "sp_add_infliction_shock",
                     "sp_add_infliction_stun",
                     "sp_add_k_animate_dead",
                     "sp_add_k_beast_training",
                     "sp_add_k_cast_bear",
                     "sp_add_k_cast_demon",
                     "sp_add_k_cast_thorn",
                     "sp_add_k_charm",
                     "sp_add_k_quake",
                     "sp_add_k_summonplant",
                     "sp_add_k_summonplant2",
                     "sp_add_k_level_beast_training",
                     "sp_add_k_level_cast_sleep",
                     "sp_add_krit_battle_mage",
                     "sp_add_krit_special_battle_mage_attack",
                     "sp_add_penalty_armageddon",
                     "sp_add_penalty_battle_mage",
                     "sp_add_penalty_berserk",
                     "sp_add_penalty_pacifism",
                     "sp_add_penalty_special_battle_mage_attack",
                     "sp_add_penalty_stone_skin",
                     "sp_add_poison_throw1",
                     "sp_add_periphery_damage_fire_ball",
                     "sp_add_periphery_damage_ice_serpent",
                     "sp_add_power_accuracy",
                     "sp_gain_power_accuracy",
                     "sp_duration_accuracy",
                     "sp_add_power_adrenalin",
                     "sp_duration_adrenalin",
                     "sp_gain_power_adrenalin",
                     "sp_add_power_armageddon",
                     "sp_duration_armageddon",
                     "sp_gain_power_armageddon",
                     "sp_add_power_badabum",
                     "sp_gain_power_badabum",
                     "sp_add_power_battle_mage",
                     "sp_duration_battle_mage",
                     "sp_gain_power_battle_mage",
                     "sp_add_power_berserk",
                     "sp_duration_berserk",
                     "sp_gain_power_berserk",
                     "sp_add_power_berserker",
                     "sp_duration_berserker",
                     "sp_gain_power_berserker",
                     "sp_duration_bless",
                     "sp_duration_blind",
                     "sp_add_power_blood",
                     "sp_duration_blood",
                     "sp_gain_power_blood",
                     "sp_duration_crue_fate",
                     "sp_duration_defenseless",
                     "sp_gain_power_defenseless",
                     "sp_add_power_demonologist",
                     "sp_gain_power_demonologist",
                     "sp_add_power_demon_slayer",
                     "sp_duration_demon_slayer",
                     "sp_gain_power_demon_slayer",
                     "sp_add_power_divine_armor",
                     "sp_duration_divine_armor",
                     "sp_gain_power_divine_armor",
                     "sp_add_power_dragon_slayer",
                     "sp_duration_dragon_slayer",
                     "sp_gain_power_dragon_slayer",
                     "sp_add_power_fire_arrow",
                     "sp_duration_fire_arrow",
                     "sp_gain_power_fire_arrow",
                     "sp_add_power_fire_ball",
                     "sp_duration_fire_ball",
                     "sp_gain_power_fire_ball",
                     "sp_duration_fire_breath",
                     "sp_add_power_fire_rain",
                     "sp_duration_fire_rain",
                     "sp_gain_power_fire_rain",
                     "sp_add_power_geyser",
                     "sp_duration_geyser",
                     "sp_gain_power_geyser",
                     "sp_add_power_ghost_sword",
                     "sp_gain_power_ghost_sword",
                     "sp_add_power_haste",
                     "sp_duration_haste",
                     "sp_gain_power_haste",
                     "sp_add_power_healing",
                     "sp_gain_power_healing",
                     "sp_add_power_holy_rain",
                     "sp_duration_holy_rain",
                     "sp_gain_power_holy_rain",
                     "sp_duration_hypnosis",
                     "sp_add_power_hypnosis",
                     "sp_gain_power_hypnosis",
                     "sp_add_power_ice_serpent",
                     "sp_duration_ice_serpent",
                     "sp_gain_power_ice_serpent",
                     "sp_duration_invisibility",
                     "sp_add_power_kamikaze",
                     "sp_gain_power_kamikaze",
                     "sp_duration_last_hero",
                     "sp_add_power_lightning",
                     "sp_duration_lightning",
                     "sp_gain_power_lightning",
                     "sp_add_power_magic_axe",
                     "sp_gain_power_magic_axe",
                     "sp_duration_magic_bondage",
                     "sp_add_power_magic_source",
                     "sp_duration_magic_source",
                     "sp_gain_power_magic_source",
                     "sp_add_power_necromancy",
                     "sp_gain_power_necromancy",
                     "sp_add_power_ogre_rage",
                     "sp_duration_ogre_rage",
                     "sp_gain_power_ogre_rage",
                     "sp_add_power_oil_fog",
                     "sp_duration_oil_fog",
                     "sp_gain_power_oil_fog",
                     "sp_add_power_pacifism",
                     "sp_duration_pacifism",
                     "sp_gain_power_pacifism",
                     "sp_add_power_pain_mirror",
                     "sp_gain_power_pain_mirror",
                     "sp_add_power_phantom",
                     "sp_duration_phantom",
                     "sp_gain_power_phantom",
                     "sp_add_power_plague",
                     "sp_duration_plague",
                     "sp_gain_power_plague",
                     "sp_duration_pygmy",
                     "sp_duration_ram",
                     "sp_duration_reaction",
                     "sp_add_power_resurrection",
                     "sp_gain_power_resurrection",
                     "sp_add_power_sacrifice",
                     "sp_gain_power_sacrifice",
                     "sp_duration_scare",
                     "sp_duration_shroud",
                     "sp_add_power_slow",
                     "sp_duration_slow",
                     "sp_gain_power_slow",
                     "sp_add_power_smile_skull",
                     "sp_duration_smile_skull",
                     "sp_gain_power_smile_skull",
                     "sp_add_power_special_battle_mage_attack",
                     "sp_add_power_stone_skin",
                     "sp_duration_stone_skin",
                     "sp_gain_power_stone_skin",
                     "sp_duration_target",
                     "sp_add_power_trap",
                     "sp_duration_trap",
                     "sp_gain_power_trap",
                     "sp_duration_weakness",
                     "sp_add_rage_holy_rage",
                     "sp_add_resist_rooted",
                     "sp_add_rush_dmg_inc_charge",
                     "sp_add_shock_battle_mage",
                     "sp_add_shock_lightning",
                     "sp_add_shock_special_archmage_lightning_attack",
                     "sp_add_shock_special_battle_mage_attack",
                     "sp_add_sleep_ray",
                     "sp_add_special_heal",
                     "sp_add_special_holy_rage",
                     "sp_addexp_battle",
                     "sp_addexp_spirit",
                     "sp_addgold_battle",
                     "sp_addgold_chest",
                     "sp_attack_undead",
                     "sp_attack_dragon",
                     "sp_attack_demon",
                     "sp_boots_speed",
                     "sp_chance_effect_blood",
                     "sp_duration_effect_blood",
                     "sp_chance_effect_burn",
                     "sp_duration_effect_burn",
                     "sp_chance_effect_charm",
                     "sp_duration_effect_charm",
                     "sp_chance_effect_corrosion",
                     "sp_duration_effect_corrosion",
                     "sp_chance_effect_curse",
                     "sp_duration_effect_curse",
                     "sp_chance_effect_freeze",
                     "sp_duration_effect_freeze",
                     "sp_chance_effect_holy",
                     "sp_duration_effect_holy",
                     "sp_chance_effect_poison",
                     "sp_duration_effect_poison",
                     "sp_chance_effect_shock",
                     "sp_duration_effect_shock",
                     "sp_chance_effect_sleep",
                     "sp_duration_effect_sleep",
                     "sp_chance_effect_slow",
                     "sp_duration_effect_slow",
                     "sp_chance_effect_stun",
                     "sp_duration_effect_stun",
                     "sp_chance_effect_weakness",
                     "sp_duration_effect_weakness",
                     "sp_chance_feat_bleeding",
                     "sp_duration_feat_bleeding",
                     "sp_chance_feat_brutality",
                     "sp_duration_feat_brutality",
                     "sp_chance_feat_increase_anger",
                     "sp_duration_feat_increase_anger",
                     "sp_chance_feat_rabid",
                     "sp_duration_feat_rabid",
                     "sp_dur_mod",
                     "sp_duration_beast_training",
                     "sp_duration_cast_sleep",
                     "sp_duration_charm",
                     "sp_duration_holy_rage",
                     "sp_duration_ray",
                     "sp_duration_rooted",
                     "sp_duration_special_aiming",
                     "sp_duration_special_battle_mage_attack",
                     "sp_duration_special_berserk",
                     "sp_duration_special_demoness_pentagramm",
                     "sp_duratoin_special_elf_song",
                     "sp_duration_special_haste",
                     "sp_duration_special_bless_attack",
                     "sp_duration_special_holy_rage",
                     "sp_duration_special_magic_shield",
                     "sp_duration_special_ogre_rage",
                     "sp_duration_special_plague",
                     "sp_duration_special_preparation",
                     "sp_duration_special_spider_web",
                     "sp_duration_special_stupid",
                     "sp_duration_special_wolf_cry",
                     "sp_gain_ap_ogre_rage",
                     "sp_gain_ap_run",
                     "sp_gain_burn_firepower",
                     "sp_gain_burn_fire_shot",
                     "sp_gain_burn_firethrow",
                     "sp_gain_burn_rail",
                     "sp_gain_burn_throw2",
                     "sp_gain_dragonslayer_krugom",
                     "sp_gain_freeze_throw3",
                     "sp_gain_heal_cast_sacrifice",
                     "sp_gain_heal_cure",
                     "sp_gain_heal_respawn",
                     "sp_gain_health_ice_totem",
                     "sp_gain_health_protective_totem",
                     "sp_gain_holy_throw3",
                     "sp_gain_HP_rooted",
                     "sp_gain_infliction_burn",
                     "sp_gain_infliction_freeze",
                     "sp_gain_infliction_poison",
                     "sp_gain_infliction_shock",
                     "sp_gain_infliction_stun",
                     "sp_gain_k_animate_dead",
                     "sp_gain_k_beast_training",
                     "sp_gain_k_cast_bear",
                     "sp_gain_k_cast_demon",
                     "sp_gain_k_cast_thorn",
                     "sp_gain_k_charm",
                     "sp_gain_k_level_beast_training",
                     "sp_gain_k_level_cast_sleep",
                     "sp_gain_k_quake",
                     "sp_gain_k_summonplant",
                     "sp_gain_k_summonplant2",
                     "sp_gain_krit_battle_mage",
                     "sp_gain_krit_special_battle_mage_attack",
                     "sp_gain_penalty_armageddon",
                     "sp_gain_penalty_battle_mage",
                     "sp_gain_penalty_berserk",
                     "sp_gain_penalty_pacifism",
                     "sp_gain_penalty_special_battle_mage_attack",
                     "sp_gain_periphery_damage_fire_ball",
                     "sp_gain_periphery_damage_ice_serpent",
                     "sp_gain_poison_throw1",
                     "sp_gain_power_special_battle_mage_attack",
                     "sp_gain_rush_dmg_inc_charge",
                     "sp_gain_shock_battle_mage",
                     "sp_gain_shock_lightning",
                     "sp_gain_shock_special_archmage_lightning_attack",
                     "sp_gain_shock_special_battle_mage_attack",
                     "sp_gain_sleep_ray",
                     "sp_gain_special_heal",
                     "sp_gain_special_holy_rage",
                     "sp_lead_unit_alchemist",
                     "sp_lead_unit_archdemon",
                     "sp_lead_unit_archer",
                     "sp_lead_unit_archmage",
                     "sp_lead_unit_barbarians",
                     "sp_lead_unit_vampire",
                     "sp_lead_unit_vampire2",
                     "sp_lead_unit_bears",
                     "sp_lead_unit_bear_white",
                     "sp_lead_unit_beholder",
                     "sp_lead_unit_beholder2",
                     "sp_lead_unit_blackdragon",
                     "sp_lead_unit_blackknight",
                     "sp_lead_unit_bluedragon",
                     "sp_lead_unit_bonedragon",
                     "sp_lead_unit_bowman",
                     "sp_lead_unit_cannoner",
                     "sp_lead_unit_catapult",
                     "sp_lead_unit_cerberus",
                     "sp_lead_unit_cyclop",
                     "sp_lead_unit_demon",
                     "sp_lead_unit_demoness",
                     "sp_lead_unit_devilfish",
                     "sp_lead_unit_dragonflies",
                     "sp_lead_unit_druid",
                     "sp_lead_unit_dryad",
                     "sp_lead_unit_dwarf",
                     "sp_lead_unit_elf",
                     "sp_lead_unit_elf2",
                     "sp_lead_unit_ent",
                     "sp_lead_unit_ent2",
                     "sp_lead_unit_footman",
                     "sp_lead_unit_footman2",
                     "sp_lead_unit_ghosts",
                     "sp_lead_unit_giant",
                     "sp_lead_unit_goblin",
                     "sp_lead_unit_goblin2",
                     "sp_lead_unit_graywolf",
                     "sp_lead_unit_greendragon",
                     "sp_lead_unit_griffin",
                     "sp_lead_unit_horseman",
                     "sp_lead_unit_hyena",
                     "sp_lead_unit_imps",
                     "sp_lead_unit_kingthorn",
                     "sp_lead_unit_knight",
                     "sp_lead_unit_miner",
                     "sp_lead_unit_necromant",
                     "sp_lead_unit_ogre",
                     "sp_lead_unit_orc",
                     "sp_lead_unit_orc2",
                     "sp_lead_unit_peasant",
                     "sp_lead_unit_pirat",
                     "sp_lead_unit_pirat2",
                     "sp_lead_unit_priest",
                     "sp_lead_unit_priest2",
                     "sp_lead_unit_reddragon",
                     "sp_lead_unit_robber",
                     "sp_lead_unit_robber2",
                     "sp_lead_unit_shaman",
                     "sp_lead_unit_skeleton",
                     "sp_lead_unit_snakes",
                     "sp_lead_unit_snake_royal",
                     "sp_lead_unit_spider",
                     "sp_lead_unit_spider_fire",
                     "sp_lead_unit_spider_undead",
                     "sp_lead_unit_spider_venom",
                     "sp_lead_unit_sprites",
                     "sp_lead_unit_thorn",
                     "sp_lead_unit_thorn_warrior",
                     "sp_lead_unit_unicorns",
                     "sp_lead_unit_werewolf",
                     "sp_lead_unit_zombies",
                     "sp_lev_inc_armageddon",
                     "sp_lev_inc_fire_arrow",
                     "sp_lev_inc_fire_ball",
                     "sp_lev_inc_fire_rain",
                     "sp_lev_inc_geyser",
                     "sp_lev_inc_ghost_sword",
                     "sp_lev_inc_healing",
                     "sp_lev_inc_holy_rain",
                     "sp_lev_inc_ice_serpent",
                     "sp_lev_inc_kamikaze",
                     "sp_lev_inc_lightning",
                     "sp_lev_inc_oil_fog",
                     "sp_lev_inc_resurrection",
                     "sp_lev_inc_sacrifice",
                     "sp_lev_inc_smile_skull",
                     "sp_lev_inc_trap",
                     "sp_mana_battle",
                     "sp_mana_map_prc",
                     "sp_power_effect_blood",
                     "sp_power_effect_burn",
                     "sp_power_effect_charm",
                     "sp_power_effect_corrosion",
                     "sp_power_effect_curse",
                     "sp_power_effect_freeze",
                     "sp_power_effect_holy",
                     "sp_power_effect_poison",
                     "sp_power_effect_shock",
                     "sp_power_effect_sleep",
                     "sp_power_effect_slow",
                     "sp_power_effect_stun",
                     "sp_power_effect_weakness",
                     "sp_power_inc",
                     "sp_power_int",
                     "sp_power_mod",
                     "sp_special_attacks_horseman_charge",
                     "sp_special_attacks_thorn_gift",
                     "sp_rage_battle_prc",
                     "sp_rage_battle",
                     "sp_rage_battle_inflow",
                     "sp_rage_map",
                     "sp_rage_predator",
                     "sp_spell_attack",
                     "sp_spell_defense",
                     "sp_spell_astral",
                     "sp_spell_fire",
                     "sp_spell_physical",
                     "sp_spell_magic",
                     "sp_spell_poison",
                     "sp_spell_holy",
                     "sp_spell_speed" }

  local sp_lead_unit_table = {}
  local last_text2

  for i = 1, table.getn( mod_list ) do
    local bonus_type = mod_list[ i ]
    local bonus = Game.Config( name_mod .. "/" .. bonus_type )

    if bonus ~= nil
    and bonus ~= "" then
      local bonus_value = text_dec( bonus, 2 )
      local text2

      if string.find( bonus_type, "sp_lead_unit_" ) then
        if sp_lead_unit_table[ bonus_value ] == nil then
          sp_lead_unit_table[ bonus_value ] = string.sub( bonus_type, string.len( "sp_lead_unit_" ) + 1 )
        else
          sp_lead_unit_table[ bonus_value ] = sp_lead_unit_table[ bonus_value ] .. "," .. string.sub( bonus_type, string.len( "sp_lead_unit_" ) + 1 )
        end
      elseif string.find( bonus_type, "sp_duration_" ) then
        local duration_type, duration_label = "", ""
        local color

        if string.find( bonus_type, "effect_" ) then
          duration_type = "<label=mod_bonus_sp_gain_infliction>"
          duration_label = "<label=" .. string.gsub( bonus_type, "sp_duration_", "" ) .. "_name> -"
          color = effect_color
        else
          duration_type = "<label=mod_bonus_spell>"
          duration_label = "<label=" .. string.gsub( bonus_type, "sp_duration", "spell" ) .. "_name> -"
          color = spell_color
        end

        text2 = "<br>" .. duration_type .. " " .. color .. duration_label  .. tc
        local text3

        if text2 == last_text2 then
          text3 = ", <label=mod_bonus_sp_duration> "
        else
          text3 = " <label=mod_bonus_sp_duration> "
        end

        if tonum( bonus_value ) > 0 then
          text3 = text3 .. pos_color .. "+"
        else
          text3 = text3 .. neg_color
        end

        if text2 == last_text2 then
          text = text .. text3 .. tostring( bonus_value ) .. tc
        else
          text = text .. text2 .. text3 .. tostring( bonus_value ) .. tc
        end
      elseif string.find( bonus_type, "sp_add_damage_bless" ) then
        text2 = "<br>" .. "<label=mod_bonus_spell>" .. " " .. spell_color .. "<label=" .. string.gsub( bonus_type, "sp_add_damage", "spell" )  .. "_name> -" .. tc
        local text3

        if text2 == last_text2 then
          text3 = ", <label=mod_bonus_sp_add_damage_bless> "
        else
          text3 = " <label=mod_bonus_sp_add_damage_bless> "
        end

        text3 = text3 .. pos_color .. "+" .. tostring( bonus_value ) .. " / +" .. tostring( bonus_value * 10 ) .. "%" .. "<label=mod_bonus_whichever_is_greater>"

        if text2 == last_text2 then
          text = text .. text3
        else
          text = text .. text2 .. text3
        end
      elseif string.find( bonus_type, "sp_add_damage_weakness" ) then
        text2 = "<br>" .. "<label=mod_bonus_spell>" .. " " .. spell_color .. "<label=" .. string.gsub( bonus_type, "sp_add_damage", "spell" )  .. "_name> -" .. tc
        local text3

        if text2 == last_text2 then
          text3 = ", <label=mod_bonus_sp_add_damage_weakness> "
        else
          text3 = " <label=mod_bonus_sp_add_damage_weakness> "
        end

        text3 = text3 .. pos_color .. "-" .. tostring( bonus_value ) .. " / -" .. tostring( bonus_value * 10 ) .. "%" .. "<label=mod_bonus_whichever_is_greater>"

        if text2 == last_text2 then
          text = text .. text3
        else
          text = text .. text2 .. text3
        end
      elseif string.find( bonus_type, "sp_add_penalty_stone_skin" ) then
        text2 = "<br>" .. "<label=mod_bonus_spell>" .. " " .. spell_color .. "<label=" .. string.gsub( bonus_type, "sp_add_penalty", "spell" )  .. "_name> -" .. tc
        local text3

        if text2 == last_text2 then
          text3 = ", <label=mod_bonus_sp_add_penalty_stone_skin> "
        else
          text3 = " <label=mod_bonus_sp_add_penalty_stone_skin> "
        end

        text3 = pos_color .. text3

        if text2 == last_text2 then
          text = text .. text3
        else
          text = text .. text2 .. text3
        end
      elseif string.find( bonus_type, "sp_gain_power_" )
      or string.find( bonus_type, "sp_add_power_" )
      or string.find( bonus_type, "sp_power_effect_" )
      or string.find( bonus_type, "sp_chance_effect_" ) then
        local power_type, power_label, mod_label = "", "", ""
        local color

        if string.find( bonus_type, "badabum" )
        or string.find( bonus_type, "battle_mage" )
        or ( string.find( bonus_type, "berserk" )
        and not string.find( bonus_type, "berserker" ) )
        or string.find( bonus_type, "blood_pentagramm" )
        or string.find( bonus_type, "ogre_rage" ) then
          power_type = "<label=mod_bonus_sp_gain_power_skill>"
          power_label = "<label=" .. string.gsub( string.gsub( bonus_type, "sp_gain_power", "special" ), "sp_add_power", "special" ) .. "_name> -"
          color = skill_color
          mod_label = "<label=mod_bonus_sp_gain_power> "
        elseif string.find( bonus_type, "sp_power_effect_" ) then
          power_type = "<label=mod_bonus_sp_gain_infliction>"
          power_label = "<label=" .. string.gsub( bonus_type, "sp_power_", "" ) .. "_name> -"
          color = effect_color
          mod_label = "<label=mod_bonus_sp_power_effect> "
        elseif string.find( bonus_type, "sp_chance_effect_" ) then
          power_type = "<label=mod_bonus_sp_gain_infliction>"
          power_label = "<label=" .. string.gsub( bonus_type, "sp_chance_", "" ) .. "_name> -"
          color = effect_color
          mod_label = "<label=mod_bonus_sp_chance_effect> "
        else
          power_type = "<label=mod_bonus_spell>"
          power_label = "<label=" .. string.gsub( string.gsub( bonus_type, "sp_gain_power", "spell" ), "sp_add_power", "spell" ) .. "_name> -"
          color = spell_color
          mod_label = "<label=mod_bonus_sp_gain_power> "
        end

        text2 = "<br>" .. power_type .. " " .. color .. power_label  .. tc
        local text3
        
        if text2 == last_text2 then
          text3 = ", " .. mod_label
        else
          text3 = " " .. mod_label
        end

        if tonum( bonus_value ) > 0 then
          text3 = text3 .. pos_color .. "+"
        else
          text3 = text3 .. neg_color
        end

        if text2 == last_text2 then
          text = text .. text3 .. tostring( bonus_value )
        else
          text = text .. text2 .. text3 .. tostring( bonus_value )
        end

        if string.find( bonus_type, "sp_gain_power_" )
        or string.find( bonus_type, "sp_power_effect_" )
        or string.find( bonus_type, "sp_chance_effect_" ) then
          text = text .. "%"
        end

        text = text .. tc
      elseif string.find( bonus_type, "sp_gain_infliction_" ) then
        local effect_label = "<label=" .. string.gsub( bonus_type, "sp_gain_infliction", "effect" ) .. "_name>"
        local effect_image = "<image=" .. string.gsub( bonus_type, "sp_gain_infliction", "itm" ) .. ".png>"
        text = text .. "<br>" .. "<label=mod_bonus_sp_gain_infliction>" .. " " .. effect_color .. effect_label .. tc .. " " .. effect_image .. " " .. "<label=mod_bonus_sp_gain_infliction_chance> "

        if tonum( bonus_value ) > 0 then
          text = text .. pos_color .. "+"
        else
          text = text .. neg_color
        end

        text = text .. tostring( bonus_value ) .. "%" .. tc

      elseif bonus_type == "sp_rage_predator" then
        text = text .. "<br>" .. ally_color .. "<label=mod_bonus_sp_rage_predator_prefix> " .. tc .. pos_color .. tostring( bonus_value ) .. tc .. ally_color .. " <label=mod_bonus_sp_rage_predator_suffix>" .. tc
      elseif bonus_type == "sp_rage_battle_prc" then
        text = text .. "<br>" .. ally_color .. "<label=mod_bonus_sp_rage_battle_prc_prefix> " .. tc .. pos_color .. tostring( bonus_value ) .. "%" .. tc .. ally_color .. " <label=mod_bonus_sp_rage_battle_prc_suffix>" .. tc
      else

        if bonus_type == "sp_power_mod" then
          text = text .. mod_color .. "<br><label=mod_bonus_" .. bonus_type .."> " .. tc .. pos_color
          bonus_value = -( bonus_value )
        else
          if tonum( bonus_value ) > 0
          or string.find( bonus_value, "%%" ) then
            text = text .. mod_color .. "<br><label=mod_bonus_" .. bonus_type .."> " .. tc .. pos_color .. "+"
          else
            text = text .. mod_color .. "<br><label=mod_bonus_" .. bonus_type .."> " .. tc .. neg_color
          end
        end

        if bonus_type == "sp_power_inc"
        or bonus_type == "sp_power_mod" then
          text = text .. tostring( bonus_value / 2 )
        else
          text = text .. tostring( bonus_value )
        end
  
        if bonus_type == "sp_mana_map_prc"
        or bonus_type == "sp_rage_battle_inflow"
        or bonus_type == "sp_rage_map"
        or bonus_type == "sp_addexp_battle"
        or bonus_type == "sp_addexp_spirit"
        or bonus_type == "sp_addgold_battle"
        or bonus_type == "sp_addgold_chest"
        or bonus_type == "sp_power_int"
        or bonus_type == "sp_power_inc"
        or string.find( bonus_type, "sp_attack_" )
        or ( string.find( bonus_type, "sp_spell" )
        and not string.find( bonus_type, "sp_spell_speed" ) ) then
          text = text .. "%"
        end

        text = text .. tc
  
        if bonus_type == "sp_power_mod" then
          local new_value = tonumber( Game.Config( "spell_power_config/mod" ) ) + bonus_value / 2
          text = text .. "<label=mod_bonus_sp_power_mod_for_prefix> " .. tostring( new_value ) .. "<label=mod_bonus_sp_power_mod_for_suffix>"
        end
      end

      last_text2 = text2
    end
  end

  local function check_lead_race( unit )
    local sp_lead_race = { demon = { archdemon = false, cerberus = false, demon = false, demoness = false, imps = false, spider_fire = false },
                           dwarf = { alchemist = false, cannoner = false, dwarf = false, giant = false, miner = false },
                           elf = { druid = false, dryad = false, elf = false, elf2 = false, ent = false, ent2 = false, sprites = false, unicorns = false, werewolf = false },
                           human = { archmage = false, bowman = false, footman = false, footman2 = false, horseman = false, knight = false, peasant = false, priest = false, priest2 = false, robber = false, robber2 = false },
                           neutral = { barbarians = false, bears = false, bear_white = false, beholder = false, beholder2 = false, blackdragon = false, bluedragon = false, cyclop = false, devilfish = false, dragonflies = false, graywolf = false, greendragon = false, griffin = false, griffin2 = false, hyena = false, kingthorn = false, pirat = false, pirat2 = false, reddragon = false, snakes = false, snake_royal = false, spider = false, spider_venom = false, thorn = false, thorn_warrior = false },
                           orc = { goblin = false, goblin2 = false, catapult = false, orc = false, orc2 = false, shaman = false, ogre = false },
                           undead = { archer = false, skeleton = false, spider_undead = false, zombies = false, ghosts = false, vampire = false, vampire2 = false, blackknight = false, necromant = false, bonedragon = false } }

    for i = 1, text_par_count( unit ) do
      local name = text_dec( unit, i )

      for race, unit_list in pairs( sp_lead_race ) do
        for unit_name, v in pairs( unit_list ) do
          if unit_name == name then
            sp_lead_race[ race ][ name ] = true
          end
        end
      end
    end
    
    local new_unit

    for race, unit_list in pairs( sp_lead_race ) do
      local break_race = false
      local unit_temp

      for unit_name, v in pairs( unit_list ) do
        if v then
          if unit_temp == nil then
            unit_temp = unit_name
          else
            unit_temp = unit_temp .. "," .. unit_name
          end
        else
          break_race = true
        end
      end

      if unit_temp ~= nil then
        if break_race then
          if new_unit == nil then
            new_unit = unit_temp
          else
            new_unit = new_unit .. "," .. unit_temp
          end
        else
          if new_unit == nil then
            new_unit = "race_" .. race
          else
            new_unit = new_unit .. "," .. "race_" .. race
          end
        end
      end
    end

    return new_unit
  end

  local sp_lead_counter = 0

  for value, unit in pairs( sp_lead_unit_table ) do
    if value ~= nil
    and value ~= ""
    and unit ~= nil
    and unit ~= "" then
      unit = check_lead_race( unit )
      sp_lead_counter = sp_lead_counter + 1

      for i = 1, text_par_count( unit ) do
        local color
        local sp_lead = text_dec( unit, i )
        local text2

        if sp_lead == "race_demon"
        or sp_lead == "race_dwarf"
        or sp_lead == "race_elf"
        or sp_lead == "race_human"
        or sp_lead == "race_orc"
        or sp_lead == "race_undead" then
          color = race_color
          text2 = race_color .. "<image=itm_" .. sp_lead .. ".png> " .. "<label=itm_" .. string.sub( sp_lead, string.len( "race_" ) + 1 ) .. ">" .. tc
        else
          color = unit_color
          text2 = unit_color .. "<label=cpsn_" .. sp_lead .. ">" .. tc
        end

        if i == 1 then
          text = text .. ally_color .. "<br><label=fight_bonus_filter_belligerent_ally> " .. tc
        end

        text = text .. color

        if i > 1 then
          if text_par_count( unit ) == 2 then
            text = text .. " and "
          elseif i == text_par_count( unit ) then
            text = text .. ", and "
          else
            text = text .. ", "
          end
        end
  
        text = text .. text2
      end

      if sp_lead_counter > 1 then
        text = text .. tc .. ": " .. pos_color .. "-" .. value .. "% <image=itm_leadership.png>" .. tc
      else
        text = text .. tc .. ": " .. pos_color .. "-" .. value .. "% <label=mod_bonus_sp_lead_unit>" .. tc
      end
    end
  end

  return text
end

-- New! Hint generator for containers (i.e. seeds, eggs, etc.)
function gen_egg_param()
  local effect_color = "<color=230,232,250>"
  local variant_color = "<color=0,187,232>"
  local stat_color = "<color=253,248,255>"
  local unit_color = "<color=240,168,4>"
  local name = Obj.name()

  -- This function is meant to get the object parameters when they're not working properly
  -- It seems like this is the case after you talk to someone in a castle and they add
  -- new items. If ITEMS_MONSTER.TXT is changed, then you need to change this to match.
  -- I don't know any other way to do this, unfortunately, but if you find another way
  -- then please let me know!
  local function brute_force_get_params( name, param )
    -- Now due to CONFIG.TXT including ITEMS.TXT (and its includes) this function is really simple!
    return Game.Config( name .. "/params/" .. param )

--[[    if name == "griffin_egg" then
      if param == "troop" then
        return "griffin"
      elseif param == "troopcount" then
        return "1-2"
      elseif param == "random" then
        return "100"
      end
    elseif name == "snake_egg" then
      if param == "troop" then
        return "snake,snake_green,snake_royal"
      elseif param == "troopcount" then
        return "2-4,2-4,1-2"
      elseif param == "random" then
        return "39,41,20"
      end
    elseif name == "bonedragon_egg" then
      if param == "troop" then
        return "bonedragon"
      elseif param == "troopcount" then
        return "1-2"
      elseif param == "random" then
        return "100"
      end
    elseif name == "spider_egg" then
      if param == "troop" then
        return "spider,spider_fire,spider_venom,spider_undead"
      elseif param == "troopcount" then
        return "2-4,1-2,2-4,2-4"
      elseif param == "random" then
        return "27,16,29,28"
      end
    elseif name == "dragon_egg" then
      if param == "troop" then
        return "greendragon"
      elseif param == "troopcount" then
        return "1-2"
      elseif param == "random" then
        return "100"
      end
    elseif name == "red_dragon_egg" then
      if param == "troop" then
        return "reddragon"
      elseif param == "troopcount" then
        return "1-2"
      elseif param == "random" then
        return "100"
      end
    elseif name == "black_dragon_egg" then
      if param == "troop" then
        return "blackdragon"
      elseif param == "troopcount" then
        return "1-2"
      elseif param == "random" then
        return "100"
      end
    elseif name == "blue_dragon_egg" then
      if param == "troop" then
        return "bluedragon"
      elseif param == "troopcount" then
        return "1-2"
      elseif param == "random" then
        return "100"
      end
    elseif name == "dfly_egg" then
      if param == "troop" then
        return "dragonfly_fire,dragonfly_lake"
      elseif param == "troopcount" then
        return "2-5,2-5"
      elseif param == "random" then
        return "50,50"
      end
    elseif name == "skeleton_grave" then
      if param == "troop" then
        return "archer,skeleton"
      elseif param == "troopcount" then
        return "3-5,3-6"
      elseif param == "random" then
        return "48,56"
      end
    elseif name == "vampire_grave" then
      if param == "troop" then
        return "vampire,vampire2"
      elseif param == "troopcount" then
        return "2-4,1-2"
      elseif param == "random" then
        return "72,32"
      end
    elseif name == "thorn_seed" then
      if param == "troop" then
        return "thorn,thorn_warrior"
      elseif param == "troopcount" then
        return "5-8,5-8"
      elseif param == "random" then
        return "50,50"
      elseif param == "altfactor" then
        return "47-76"
      elseif param == "alttroop" then
        return "kingthorn"
      elseif param == "troopcount" then
        return "1-2"
      elseif param == "random" then
        return "100"
      end
    end

    return nil]]
  end

  local troop = Obj.get_param( "troop" )

  if troop == "" then
    troop = brute_force_get_params( name, "troop" )
  end

  local troopcnt = Obj.get_param( "troopcount" )

  if troopcnt == "" then
    troopcnt = brute_force_get_params( name, "troopcount" )
  end

  local trand = Obj.get_param( "random" )

  if trand == "" then
    trand = brute_force_get_params( name, "random" )
  end

  local factor = Logic.cur_lu_item( Obj.name(), "count" )
  local altfactor = Obj.get_param( "altfactor" )

  if altfactor == "" then
    altfactor = brute_force_get_params( name, "altfactor" )
  end

  local function fill_tables( troop, troopcnt, trand )
    local troops, troopcnts, trands = {}, {}, {}
    local numberoftroops = text_par_count( troop )
  
    for i = 1, numberoftroops do
      local substring = text_dec( troop, i )
      table.insert( troops, substring )
      local substring = text_dec( troopcnt, i )
      table.insert( troopcnts, substring )
      local substring = text_dec( trand, i )
      table.insert( trands, substring )
    end

    return troops, troopcnts, trands
  end

  local troops, troopcnts, trands = fill_tables( troop, troopcnt, trand )

  local function get_weight( trands )
    local totalweight = 0
  
    for i = 1, table.getn( trands ) do
      totalweight = totalweight + tonumber( trands[ i ] )
    end

    return totalweight
  end

  local totalweight = get_weight( trands )
  local text = ""

  local function gen_poss_text( troops, troopcnts, trands, totalweight, altfactor, indent )
    local text = ""

    for i = 1, table.getn( troops ) do
      local poss = round( tonumber( trands[ i ] ) / totalweight * 100 )
      local indentstring = ""

      if indent ~= nil then
        indentstring = "  "
      end

      if poss == 100 then
        text = text .. "<br>" .. indentstring .. "<label=itm_egg_produces> " .. stat_color .. troopcnts[ i ] .. "</color>"
      else
        text = text .. "<br>" .. indentstring .. effect_color .. tostring( poss ) .. "%</color> <label=itm_egg_produce> " .. stat_color .. troopcnts[ i ] .. "</color>"
      end
    
      if tonumber( troopcnts[ i ] ) == 1 then
        text = text .. unit_color .. " <label=cpn_" .. troops[ i ] .. "></color>"
      else
        text = text .. unit_color .. " <label=cpsn_" .. troops[ i ] .. "></color>"
      end

      local container = ""

      if string.find( Obj.name(), "egg" ) then
        container = "egg"
      elseif string.find( Obj.name(), "grave" ) then
        container = "grave"
      elseif string.find( Obj.name(), "seed" ) then
        container = "seed"
      else
        container = "container"
      end

      if altfactor == nil then
        text = text .. " <label=itm_egg_per> <label=itm_egg_" .. container .. ">"
      else
        text = text .. " <label=itm_egg_per> " .. stat_color .. altfactor .. "</color> <label=itm_egg_" .. container .. "s>"
      end
    end

    return text
  end

  local function get_alt_data()
    local troop = Obj.get_param( "alttroop" )

    if troop == "" then
      troop = brute_force_get_params( name, "alttroop" )
    end

    local troopcnt = Obj.get_param( "alttroopcount" )

    if troopcnt == "" then
      troopcnt = brute_force_get_params( name, "alttroopcount" )
    end

    local trand = Obj.get_param( "altrandom" )

    if trand == "" then
      trand = brute_force_get_params( name, "altrandom" )
    end

    return troop, troopcnt, trand
  end

  if altfactor ~= nil
  and altfactor ~= "" then
    local altfactormin, altfactormax = text_range_dec( altfactor )

    if factor < altfactormin then
      if table.getn( troops ) > 1 then
        text = " <label=itm_egg_uncertain><br>"
      else
        text = "<br>"
      end

      text = text .. gen_poss_text( troops, troopcnts, trands, totalweight )
    elseif factor >= altfactormax then
      troop, troopcnt, trand = get_alt_data()
      troops, troopcnts, trands = fill_tables( troop, troopcnt, trand )
      totalweight = get_weight( trands )
      if table.getn( troops ) > 1 then
        text = " <label=itm_egg_uncertain><br>"
      else
        text = "<br>"
      end

      text = text .. gen_poss_text( troops, troopcnts, trands, totalweight, altfactor )
    else
      local num = factor - altfactormin + 1
      local den = altfactormax - altfactormin + 1
      local poss = round( num / den * 100 )

      if table.getn( troops ) > 1 then
        text = " <label=itm_egg_uncertain>"
      end

      text = text .. "<br>" .. variant_color .. tostring( 100 - poss ) .. "%</color> <label=itm_egg_variant1>"
      text = text .. gen_poss_text( troops, troopcnts, trands, totalweight, nil, true )
      troop, troopcnt, trand = get_alt_data()
      troops, troopcnts, trands = fill_tables( troop, troopcnt, trand )
      totalweight = get_weight( trands )
      text = text .. "<br>" .. variant_color .. tostring( poss ) .. "%</color> <label=itm_egg_variant2>"
      text = text .. gen_poss_text( troops, troopcnts, trands, totalweight, altfactor, true )
    end
  else
    if table.getn( troops ) > 1 then
      text = " <label=itm_egg_uncertain><br>"
    else
      text = "<br>"
    end

    text = text .. gen_poss_text( troops, troopcnts, trands, totalweight )
  end

  return text
end


--New! Function for generating children hint
function gen_itm_kid_hint( par )
  local color = "<color=255,243,179>"
  local effect_color = "<color=230,232,250>"
  local stat_color = "<color=253,248,255>"
  local spell_color = "<color=0,187,232>"
  local spirit_color = "<color=243,107,8>"
  local unit_color = "<color=240,168,4>"
  local race_color = "<color=217,217,25>"

  -- "Quick and Dirty's"
  if par == "astral"
--  or par == "astral_resist"
  or par == "attack"
  or par == "attack_with_abbrev"
  or par == "attack_abbrev"
  or par == "base_damage"
  or par == "base_damage_with_abbrev"
  or par == "base_damage_abbrev"
  or par == "fire"
--  or par == "fire_resist"
  or par == "krit"
  or par == "krit_with_abbrev"
  or par == "krit_abbrev"
  or par == "damage"
  or par == "defense"
  or par == "defense_with_abbrev"
  or par == "defense_abbrev"
  or par == "enemy"
  or par == "health"
  or par == "health_with_abbrev"
  or par == "health_abbrev"
  or par == "init"
  or par == "init_with_abbrev"
  or par == "init_abbrev"
  or par == "lr"
  or par == "lr_with_abbrev"
  or par == "lr_abbrev"
  or par == "magic"
--  or par == "magic_resist"
  or par == "morale"
  or par == "morale_with_abbrev"
  or par == "morale_abbrev"
  or par == "physical"
--  or par == "physical_resist"
  or par == "poison"
--  or par == "poison_resist"
  or par == "resist"
  or par == "resistance"
  or par == "speed"
  or par == "speed_with_abbrev"
  or par == "speed_abbrev"
  or par == "ur"
  or par == "ur_with_abbrev"
  or par == "ur_abbrev" then
    return color .. "<label=itm_kid_" .. par .. "></color>"
  elseif par == "colon_space" then
    return color .. ": </color>"
  elseif par == "comma_space_and_space" then
    return color .. ", and </color>"
  elseif par == "comma_space" then
    return color .. ", </color>"
  elseif par == "end" then
    return color .. ".</color>"
  elseif par == "space" then
    return color .. " </color>"
  elseif par == "space_and_space" then
    return color .. " and </color>"
  elseif par == "space_slash_space" then
    return color .. " / </color>"
  end

  local text = ""

  local function protect_text_dec( arg, i )
    local new_string, replaces = string.gsub( arg, ",", "" )

    if replaces + 1 < i then
      return nil
    else
      return text_dec( arg, i )
    end
  end

  local function get_function_parameters( par )
    local par_type = protect_text_dec( par, 1 )
    local par_type_level = tonum( protect_text_dec( par, 2 ) )
    
    return par_type, par_type_level
  end

  local function get_gain_type_value( par, par_type_level, parloc1, parloc2, unit_level )

    if parloc1 == nil then
      parloc1 = 3
    end

    if parloc2 == nil then
      parloc2 = 4
    end

    local par_gain = protect_text_dec( par, parloc1 )
    
    if par_gain == nil then
      par_gain = 1
    else
      par_gain = tonumber( par_gain )
    end
    
    local par_gain_type = protect_text_dec( par, parloc2 )

    if par_gain_type == nil
    or par_gain_type == "" then
      par_gain_type = "plus_power_percent"
    end

    local par_type_kid_level = false

    if string.find( par_gain_type, "power_percent" ) then
      par_type_kid_level = true
    end

    local kid_level = 1
    
    if par_type_kid_level == true then
      kid_level = Obj.price()
    end
    
    local value
    if unit_level == nil then
      value = math.max( math.floor( kid_level * par_type_level * par_gain ), 1 )
    else
      value = math.ceil( ( kid_level + ( 5 - unit_level ) * 5 ) * par_gain )
    end

    return par_gain_type, value
  end

  if string.find( par, "preamble" )
  or string.find( par, "postamble" ) then
    local labelname = protect_text_dec( par, 1 )
    local gender = protect_text_dec( par, 2 )
    text = text .. "<label=itm_kid_" .. gender .. "_" .. labelname .. ">"

  elseif string.find( par, "value_only" ) then
    local dummy, skill_level = get_function_parameters( par )
    
    if skill_level ~= nil then
      local skill_gain_type, value = get_gain_type_value( par, skill_level )
      text = text .. gen_dmg_common_hint( skill_gain_type, value, nil, nil, stat_color, "</color>" ) .. "."
    end

  elseif string.find( par, "astral_damage" )
  or string.find( par, "fire_damage" )
  or string.find( par, "magic_damage" )
  or string.find( par, "physical_damage" )
  or string.find( par, "poison_damage" ) then
    local damage, damage_level = get_function_parameters( par )

    if damage_level ~= nil then
      local damage_gain_type, value = get_gain_type_value( par, damage_level )
      text = text .. " and " .. gen_dmg_common_hint( damage_gain_type, value, nil, nil, stat_color, "</color>" ) .. " <label=itm_kid_" .. damage .. ">" .. "."
    end

  elseif string.find( par, "astral_eresist" )
  or string.find( par, "astral_resist" )
  or string.find( par, "fire_eresist" )
  or string.find( par, "fire_resist" )
  or string.find( par, "magic_eresist" )
  or string.find( par, "magic_resist" )
  or string.find( par, "physical_eresist" )
  or string.find( par, "physical_resist" )
  or string.find( par, "poison_eresist" )
  or string.find( par, "poison_resist" ) then
    local resist, resist_level = get_function_parameters( par )

    if resist_level ~= nil then
      local resist_gain_type, value = get_gain_type_value( par, resist_level )
      text = text .. color .. "<label=itm_kid_" .. resist .. ">: </color>" .. gen_dmg_common_hint( resist_gain_type, value, nil, nil, stat_color, "</color>" ) .. "."
    end

  elseif string.find( par, "effect_" ) then
    local effect, effect_level = get_function_parameters( par )
    
    if effect_level ~= nil then
      local effect_display = protect_text_dec( par, 3 )
      local effect_gain_type, value = get_gain_type_value( par, effect_level, 4, 5 )

      if effect_display == "start" then
        text = text .. color .. "<label=itm_kid_effect> </color>" .. effect_color .. "<label=itm_kid_" .. effect .. "></color> - "

      elseif effect_display == "starts" then
        text = text .. color .. "<label=itm_kid_effects> </color>" .. effect_color .. "<label=itm_kid_" .. effect  .. "></color>"

      elseif effect_display == "comma_space" then
        text = text .. effect_color .. ", <label=" .. effect .. "_name></color> - "

      elseif effect_display == "and_name_end" then
        text = text .. effect_color .. " and <label=" .. effect .. "_name></color> - "

      elseif effect_display == "comma_and_name_end" then
        text = text .. effect_color .. ", and <label=" .. effect .. "_name></color> - "

      elseif effect_display == "bonus"
      or effect_display == "penalty"
      or effect_display == "power" then
        text = text .. color .. "<label=itm_kid_effect_" .. effect_display .. "> </color>" .. gen_dmg_common_hint( effect_gain_type, value, nil, nil, stat_color, "</color>" )

      elseif effect_display == "blood"
      or effect_display == "burn"
      or effect_display == "charm"
      or effect_display == "corrosion"
      or effect_display == "curse"
      or effect_display == "fear"
      or effect_display == "freeze"
      or effect_display == "holy"
      or effect_display == "poison"
      or effect_display == "shock"
      or effect_display == "sleep"
      or effect_display == "slow"
      or effect_display == "stun"
      or effect_display == "weakness" then
        local infliction = string.gsub( effect_display, string.sub( effect_display, 1, 1 ), string.upper( string.sub( effect_display, 1, 1 ) ), 1 )
        text = text .. ", <label=itm_kid_effect_infliction> " .. infliction .. ": " .. gen_dmg_common_hint( effect_gain_type, value, nil, nil, stat_color, "</color>" )

      elseif string.find( effect_display, "duration" ) then
        if effect_display == "and_duration" then
          text = text .. " and "
        elseif effect_display == "comma_and_duration" then
          text = text .. ", and "
        end
  
        text = text .. "<label=itm_kid_effect_duration> " .. gen_dmg_common_hint( "plus_power", effect_level, nil, nil, stat_color, "</color>" )

      elseif effect_display == "no_init_penalty" then
        text = text .. ", " .. stat_color .. "No Initiative Penalty</color>"

      elseif effect_display == "value" then
        text = text .. gen_dmg_common_hint( effect_gain_type, value, nil, nil, stat_color, "</color>" )

      elseif effect_display == "end" then
        text = text .. "."
      end
    end

  elseif string.find( par, "skill_" ) then
    local skill, skill_level = get_function_parameters( par )
    
    if skill_level ~= nil then
      local skill_gain_type, value = get_gain_type_value( par, skill_level )

      if skill == "skill_scholar" then
        local mod = Game.Config( "spell_power_config/mod" )
        local den_scholar = Game.Config( "spell_power_config/den_scholar" )
        local intellect = tostring( mod - skill_level / den_scholar )
        value = value / den_scholar
        text = text .. color .. "<label=itm_kid_" .. skill .. "> </color>" .. gen_dmg_common_hint( skill_gain_type, value, nil, nil, stat_color, "</color>" ) .. " for every " .. stat_color .. intellect .. "</color> Intelligence."
      elseif skill == "skill_archery"
      or skill == "skill_offense" then
        text = text .. color .. "<label=itm_kid_" .. skill .. "> </color>" .. gen_dmg_common_hint( skill_gain_type, value, nil, nil, stat_color, "</color>" )

        if skill_level == 1 then
          text = text .. "."
        end
      elseif skill == "skill_navigation" then
        text = text .. color .. "<label=itm_kid_" .. skill .. "> </color>" .. gen_dmg_common_hint( "plus_power", skill_level, nil, nil, stat_color, "</color>" ) .. ", Critical Hit: " .. gen_dmg_common_hint( skill_gain_type, value, nil, nil, stat_color, "</color>" ) .. "."
      elseif skill == "skill_necromancy" then
        text = text .. color .. "<label=itm_kid_" .. skill .. "> <label=itm_kid_lr>: </color>" .. gen_dmg_common_hint( skill_gain_type, value, nil, nil, stat_color, "</color>" ) .. "."
      else
        text = text .. color .. "<label=itm_kid_" .. skill .. "> </color>" .. gen_dmg_common_hint( skill_gain_type, value, nil, nil, stat_color, "</color>" ) .. "."
      end
    end

  elseif string.find( par, "spell_" ) then
    local spell, spell_level = get_function_parameters( par )
    
    if spell_level ~= nil then
      local spell_display = protect_text_dec( par, 3 )
      local spell_gain_type, value = get_gain_type_value( par, spell_level, 4, 5 )

      if spell_display == "start" then
        text = text .. color .. "<label=itm_kid_spell> </color>" .. spell_color .. "<label=" .. spell .. "_name></color> - "

      elseif spell_display == "starts" then
        text = text .. color .. "<label=itm_kid_spells> </color>" .. spell_color .. "<label=" .. spell .. "_name></color>"

      elseif spell_display == "fire_starts" then
        text = text .. color .. "<label=itm_kid_fire_spells> </color>" .. spell_color .. "<label=" .. spell .. "_name></color>"

      elseif spell_display == "attack_starts" then
        text = text .. color .. "<label=itm_kid_attack_spells> </color>" .. spell_color .. "<label=" .. spell .. "_name></color>"

      elseif spell_display == "defense_starts" then
        text = text .. color .. "<label=itm_kid_defense_spells> </color>" .. spell_color .. "<label=" .. spell .. "_name></color>"

      elseif spell_display == "comma_space" then
        text = text .. spell_color .. ", <label=" .. spell .. "_name></color>"

      elseif spell_display == "and_name_end" then
        text = text .. spell_color .. " and <label=" .. spell .. "_name></color> - "

      elseif spell_display == "comma_and_name_end" then
        text = text .. spell_color .. ", and <label=" .. spell .. "_name></color> - "

      elseif spell_display == "bonus"
      or spell_display == "count"
      or spell_display == "distance"
      or spell_display == "mana"
      or spell_display == "penalty"
      or spell_display == "power"
      or spell_display == "prc" then
        text = text .. color .. "<label=itm_kid_spell_" .. spell_display .. "> " .. gen_dmg_common_hint( spell_gain_type, value, nil, nil, stat_color, "</color>" )

      elseif spell_display == "burn"
      or spell_display == "freeze"
      or spell_display == "holy"
      or spell_display == "poison"
      or spell_display == "shock"
      or spell_display == "stun" then
        local infliction = string.gsub( spell_display, string.sub( spell_display, 1, 1 ), string.upper( string.sub( spell_display, 1, 1 ) ), 1 )
        text = text .. ", <label=itm_kid_spell_infliction> " .. infliction .. ": " .. gen_dmg_common_hint( spell_gain_type, value, nil, nil, stat_color, "</color>" )

      elseif string.find( spell_display, "duration" ) then
        if spell_display == "and_duration" then
          text = text .. " and "
        elseif spell_display == "comma_and_duration" then
          text = text .. ", and "
        end
  
        text = text .. "<label=itm_kid_spell_duration> " .. gen_dmg_common_hint( "plus_power", spell_level, nil, nil, stat_color, "</color>" )

      elseif spell_display == "no_init_penalty" then
        text = text .. ", " .. stat_color .. "No Initiative Penalty</color>"

      elseif spell_display == "value" then
        text = text .. gen_dmg_common_hint( spell_gain_type, value, nil, nil, stat_color, "</color>" )
      end
    end

  elseif string.find( par, "unit_" ) then
    local unit, bonus_level = get_function_parameters( par )
    
    if bonus_level ~= 0 then
      local unit_display = protect_text_dec( par, 3 )
      local level_inc = 0

      if string.find( par, "level+" ) then
        local level_inc_string = protect_text_dec( par, 6 )
        level_inc = tonumber( string.sub( level_inc_string, 7 ) )
      end

      if unit_display == "start" then
        text = text .. color .. "<label=itm_kid_unit> </color>" .. unit_color .. "<label=" .. string.gsub( unit, "unit_", "cpsn_" ) .. "></color> - "

      elseif unit_display == "starts" then
        text = text .. color .. "<label=itm_kid_units> </color>" .. unit_color .. "<label=" .. string.gsub( unit, "unit_", "cpsn_" ) .. "></color>"

      elseif unit_display == "comma_space" then
        text = text .. unit_color .. ", <label=" .. string.gsub( unit, "unit_", "cpsn_" ) .. "></color>"

      elseif unit_display == "and_name_end" then
        text = text .. unit_color .. " and <label=" .. string.gsub( unit, "unit_", "cpsn_" ) .. "></color> - "

      elseif unit_display == "comma_and_name_end" then
        text = text .. unit_color .. ", and <label=" .. string.gsub( unit, "unit_", "cpsn_" ) .. "></color> - "

      elseif unit_display == "attack"
      or unit_display == "defense" then
        local value = tonum( protect_text_dec( par, 4 ) )
        unit = string.gsub( unit, "unit_", "" )
        local unit_level = Logic.cp_level( unit ) + level_inc
        text = text .. gen_dmg_common_hint( "plus_power", value * bonus_level * unit_level, nil, nil, stat_color, "</color>" )

      elseif unit_display == "krit"
      or unit_display == "health"
      or unit_display == "lr" then
        unit = string.gsub( unit, "unit_", "" )
        local unit_level = Logic.cp_level( unit ) + level_inc
        local unit_gain_type, value = get_gain_type_value( par, bonus_level, 4, 5, unit_level )
        text = text .. gen_dmg_common_hint( unit_gain_type, value, nil, nil, stat_color, "</color>" )

      elseif unit_display == "value" then
        local unit_gain_type, value = get_gain_type_value( par, bonus_level, 4, 5 )
        text = text .. gen_dmg_common_hint( unit_gain_type, value, nil, nil, stat_color, "</color>" )
      end
    end

  elseif string.find( par, "_race" ) then
    local race, race_level = get_function_parameters( par )
    
    if race_level ~= 0 then
      local race_display = protect_text_dec( par, 3 )

      if race_display == "start" then
        text = text .. color .. "<label=itm_kid_race> </color>" .. race_color .. "<label=inf_" .. race .. "_heads></color> - "

      elseif race_display == "starts" then
        text = text .. color .. "<label=itm_kid_races> </color>" .. race_color .. "<label=inf_" .. race .. "_heads></color>"

      elseif race_display == "start_with_units" then
        text = text .. color .. "<label=itm_kid_race> </color>" .. race_color .. "<label=inf_" .. race .. "_heads></color>"

      elseif race_display == "comma_space" then
        text = text .. race_color .. ", <label=" .. race .. "_heads></color>"

      elseif race_display == "and_name_end" then
        text = text .. race_color .. " and <label=" .. race .. "_heads></color> - "

      elseif race_display == "comma_and_name_end" then
        text = text .. race_color .. ", and <label=" .. race .. "_heads></color> - "

      elseif race_display == "attack"
      or race_display == "defense" then
        text = text .. stat_color .. "+Unit Level</color>"

      elseif race_display == "krit"
      or race_display == "health"
      or race_display == "lr" then
        local race_gain_type, value = get_gain_type_value( par, race_level, 4, 5 )
        text = text .. gen_dmg_common_hint( race_gain_type, value, nil, nil, stat_color, "</color>" )

      elseif race_display == "value" then
        local race_gain_type, value = get_gain_type_value( par, race_level, 4, 5 )
        text = text .. gen_dmg_common_hint( race_gain_type, value, nil, nil, stat_color, "</color>" )
      end
    end

  elseif string.find( par, "spirit_" ) then
    local spirit, spirit_level = get_function_parameters( par )

    if spirit_level ~= 0 then
      local spirit_display = protect_text_dec( par, 3 )

      if spirit_display == "start" then
        local spirit_name = protect_text_dec( par, 4 )
        text = text .. color .. "<label=itm_kid_spirit> </color>" .. spirit_color .. "<label=spirit_" .. spirit_name .. "> <label=" .. string.gsub( spirit, "spirit_", "cpsn_" ) .. "></color> - "

      elseif spirit_display == "starts" then
        text = text .. color .. "<label=itm_kid_spirits> </color>" .. spirit_color .. "<label=" .. string.gsub( spirit, "spirit_", "cpsn_" ) .. "></color>"

      elseif spirit_display == "comma_space" then
        text = text .. spirit_color .. ", <label=" .. string.gsub( spirit, "spirit_", "cpsn_" ) .. "></color>"

      elseif spirit_display == "and_name_end" then
        text = text .. spirit_color .. " and <label=" .. string.gsub( spirit, "spirit_", "cpsn_" ) .. "></color> - "

      elseif spirit_display == "comma_and_name_end" then
        text = text .. spirit_color .. ", and <label=" .. string.gsub( spirit, "spirit_", "cpsn_" ) .. "></color> - "

      elseif spirit_display == "attack"
      or spirit_display == "defense"
      or spirit_display == "krit"
      or spirit_display == "health"
      or string.find( spirit_display, "_resist" ) then
        local spirit_gain_type, value = get_gain_type_value( par, spirit_level, 4, 5 )
        text = text .. gen_dmg_common_hint( spirit_gain_type, value, nil, nil, stat_color, "</color>" )

      elseif spirit_display == "value" then
        local spirit_gain_type, value = get_gain_type_value( par, spirit_level, 4, 5 )
        text = text .. gen_dmg_common_hint( spirit_gain_type, value, nil, nil, stat_color, "</color>" )
      end
    end
  end

  return text
end

function gen_itm_menu_hint()

    local res = ""
    if Obj.where()~=2 and not Obj.props("wife") then
        res="<label=itm_main_menu>"
    end
  return res

end

function gen_itm_name()

	if Obj.props(0)~="" and Obj.props(0)~=nil then
  	if Obj.props("wife") then
   		return " ( <label=itm_wife> )"
  	end 	
  	if Obj.props("child") then
   		return " ( <label=itm_chid> )"
  	end 
  	return ""
  else 
  	return ""
  end 
end

function gen_itm_race()
 local mr = "<br><label=itm_race> "
	
 if Obj.props(0)~="" and Obj.props(0)~=nil then
   local race = Obj.race()
 	 return mr.."<label=itm_"..race..">"
 end 

 return ""

end

function gen_itm_count()
 local count=Obj.get_param("item_count")
 if count ~= "" and count ~= nil then
 	return count
 else
 	return ""
 end 
	
end

function gen_itm_item()
 local count=Obj.get_param("item_add")
 if count ~= "" and count ~= nil then
 	return "<label=itm_"..count.."_name>"
 else
 	return ""
 end 
	
end

function gen_itm_gold( par )
  local param = Obj.get_param( "gold" )

  if param ~= ""
  and param ~= nil then
    param=tonumber( param )
    local mnog=1
    if par == "level" then
 		   mnog = tonumber( Logic.hero_lu_var( "level" ) )
    end 

    return tostring(param*mnog)
  else 
    return ""
  end 

 	return ""
end

function gen_itm_param(par)
 local count=text_par_count(par)
 if count>1 then 
 	local param=Obj.get_param(text_dec(par,1))
 	local suffiks=text_dec(par,2)
 	return param..suffiks
 else 
  local returnval = Obj.get_param(par)

  if par == "win" then
    local objname = Obj.name()
    
    if string.find( objname, "wife" ) then
      local kid = Obj.get_param( "kid" )
      local sex = Obj.get_param( "sex" )

      if sex == "1" then
        local wifelabel = "<br><color=138,138,132>(<label=itm_" .. objname .. "_name> <label=itm_wife_baby> "
        local victories = 10 - tonumber( returnval )
        local victorylabel = " <label=itm_wife_baby_victories>)."

        if kid == "" then
          kid = 0
        end

        local kidlabel = "<label=itm_wife_expecting" .. kid .. "> "

        if victories == 1 then
          victorylabel = " <label=itm_wife_baby_victory>)"
        end

        returnval = wifelabel .. kidlabel .. tostring( victories ) .. victorylabel
      else
        returnval = ""
      end
    end
  end

 	return returnval
 end 
 	return ""
end

function gen_itm_dragon(par)
 	local param=Obj.get_param("dragon")
 	if param~="" and param~="0" and param~=nil then
 		return "<label=cpn_"..param..">"
 	else 
 		return "<label=itm_nodragon>"
 	end 
end

function gen_itm_zlogn(par)
 	local param=Obj.get_param("use")
 	if param~="" and param~=nil then
 		local cnt=tonumber(param)
 		if cnt>=11 then return "<label=itm_egnum_st_4>" end 
 		if cnt>=8 then return "<label=itm_egnum_st_3>" end 
 		if cnt>=4 then return "<label=itm_egnum_st_2>" end 
 		if cnt>=1 then return "<label=itm_egnum_st_1>" end 
 		if cnt==0 then return "<label=itm_egnum_st_0>" end 
 	else 
 		return "<label=itm_egnum_st_0>"
 	end 
end
function gen_itm_scroll()
 local count=Obj.get_param("scroll")
 if count ~= "" and count ~= nil then
 	return "<label=spell_"..count.."_name>"
 else
 	return ""
 end 
	
end

function gen_item_text()
 local label=Obj.get_param("label")
 local text_tmp=Obj.get_param("text")
 local text = "<label="..string.gsub(label, "number", text_tmp)..">"
 	return text

end

function gen_itm_upgrade()
 local mr = "<br>"
 local upgrade = Obj.get_param("upgrade")
 if upgrade~="" and upgrade~=nil then
 	local count=text_par_count(upgrade)
 	local fnt=""
 	for i=1,count do
 		if Obj.name()==text_dec(upgrade,i) then
 			fnt="<label=itm_upgrade_cur>"
 		else
 			fnt="<label=itm_upgrade_up>"
 		end 
 		mr=mr.."<br>"..fnt.." - <label=itm_"..text_dec(upgrade,i).."_name>"
 	end 
 	return mr
 else
 	return ""
 end 
	
end

function gen_itm_state()
 local mr = ""
 local upgrade = Obj.get_param("upgrade")
 if Obj.moral()==0 and Obj.props("moral") then mr="<br><label=itm_state_out>" end 
 if Obj.upg()~=nil and Obj.upg()~="" then --Obj.moral()~=0 and
 	mr="<br><label=itm_state_upgrade>"
 end 
 
 if Obj.where()>2 and Obj.where()<5 then 
 	return mr	
 else
 	return ""
 end 
end

function gen_itm_type()
	local mr="<br><br><label=itm_type> "
	if Obj.props(0)~="" and Obj.props(0)~=nil then
   return mr.."<label=itm_"..Obj.props(0)..">"
  end 
  if Obj.props("quest") then
   return mr.."<label=itm_quest>"
  end 
  if Obj.props("wife") then
   return "" --<br><br><label=itm_wife>"
  end 
  if Obj.props("child") then
   return "" --<br><br><label=itm_child>"
  end 
  if Obj.props("map") then
   return mr.."<label=itm_map>"
  end 
  if Obj.props("usable") then
   return mr.."<label=itm_usual>"
  end 
  if Obj.props("container") then
   return mr.."<label=itm_resource>"
  end 
  
  --itm_diamond
  
  if Obj.get_param("sell")=="1" then
  	return mr.."<label=itm_diamond>"
  end
  if Obj.get_param("recept")=="1" then
  	return mr.."<label=itm_recept>"
  end

  return mr.."Unknow item type!"
end

function gen_itm_price()
  if Obj.props("quest") or Obj.props("wife") or Obj.props("child") or Obj.where()==2 then
   return ""
  else
   return "<br><label=itm_price> "..tostring(Obj.price())
  end 
  return mr.."Not price!"
end

function gen_itm_moral()

-- 0-5 5-20 20-40 --- 60-80 80-95 95-100  

  local moral = Obj.moral()
  local mr = "<br><label=itm_moral> "
	
 if Obj.props("moral") then
  if moral<=5 then
    return mr.."<label=itm_moral_l3> (" .. tostring(moral) .. ")"
  end
  if moral>5 and moral<=20 then
    return mr.."<label=itm_moral_l2> (" .. tostring(moral) .. ")"
  end
  if moral>20 and moral<=40 then
    return mr.."<label=itm_moral_l1> (" .. tostring(moral) .. ")"
  end
  if moral>40 and moral<=60 then
    return mr.."<label=itm_moral_n0> (" .. tostring(moral) .. ")"
  end
  if moral>60 and moral<=80 then
    return mr.."<label=itm_moral_h1> (" .. tostring(moral) .. ")"
  end
  if moral>80 and moral<=95 then
    return mr.."<label=itm_moral_h2> (" .. tostring(moral) .. ")"
  end
  if moral>95 then
    return mr.."<label=itm_moral_h3> (" .. tostring(moral) .. ")"
  end
 else 
	return ""
 end 	
		return ""
end

function map_image_gen()
 local map=Obj.get_param("map")
 local image=Obj.get_param("image")

 image = "<image="..string.gsub(image,"number",map)..".png>"
 return image

end
