-- ***********************************************
-- * Íåáåñíàÿ Ñòðàæà
-- ***********************************************

function special_sky_guard()
 	local ccnt = Attack.cell_count()
	 local count = 0
 	local summon_cell = {}
	
  for i = 0, ccnt - 1 do
		  local cell = Attack.cell_get( i )

 		 if empty_cell( cell )
			 and Attack.cell_dist( 0, cell ) < 3 then
 		 		table.insert( summon_cell, cell )
 		 end 
 	end 
	
  if table.getn( summon_cell ) == 0 then return true end -- ???

--  target = summon_cell[ Game.CurLocRand( 1,table.getn( summon_cell ) ) ]
  local target = summon_cell[ Game.Random( 1,table.getn( summon_cell ) ) ]
  Attack.aseq_rotate( 0, target, "special" )
  dmgts = Attack.aseq_time( 0, "x" )

  --íàõîäèì áëèæàéøåãî âðàãà
  local nearest_dist, nearest_enemy, ang_to_enemy = 10e10, nil, 0

  for i = 1, Attack.act_count() - 1 do
    if Attack.act_enemy( i ) then
      local d = Attack.cell_dist( target, i )

      if d < nearest_dist then nearest_dist = d; nearest_enemy = i; end
    end
  end

  local k_min, k_max = correct_damage_minmax( Attack.get_caa( 0 ), text_range_dec( Attack.get_custom_param( "k" ) ) )
  local k = apply_difficulty_level_talent_bonus( Game.Random( k_min, k_max ) )
  k = k * ( 1 + tonumber( skill_power2( "glory", 3 ) ) / 100 )
--  local k = Game.CurLocRand( text_range_dec( Attack.get_custom_param( "k" ) ) ) --êîýô.

  if nearest_enemy ~= nil then ang_to_enemy = Attack.angleto( target, nearest_enemy ) end

  local king_count = Attack.act_size( 0 )  -- ñêîëüêî ìàãîâ
  local summon_unit = "griffin_spirit"
  local king_name = Attack.act_name( 0 )
  --ëèäåðñòâî ìàãîâ è ltvjyjd
  local king_lead = Attack.atom_getpar( king_name, "leadership" )
  local summon_lead = Attack.atom_getpar( summon_unit, "leadership" )
  -- ñêîëüêî ìîæíî ïðèçâàòü ïî ëèäåðñòâó
  local summon_count = math.ceil( king_lead * king_count / summon_lead * k / 100 --[[* ( 1 + tonumber( skill_power2( "summonner", 1 ) / 100 ) ) ]] )
  -- ðåàëüíî
  Attack.act_spawn( target, 0, summon_unit, ang_to_enemy, summon_count )
  Attack.act_nodraw( target, true )
  Attack.act_nodraw( target, false, dmgts )--+dmgts1 )
  Attack.act_animate( target, "appear", dmgts )
  fix_hitback( target )
  apply_hero_attack_defense_bonuses( target )
  Attack.log_label( "add_blog_summon_0" ) -- ðàáîòàåò
  Attack.log_special( summon_count, "<label=cpsn_" .. summon_unit .. ">" ) -- ðàáîòàåò

  return true
end

-- ***********************************************
-- * Îáîäðåíèå
-- ***********************************************
function calccells_special_encouragement()
	 for i = 0, Attack.cell_count() - 1 do
  		local cell = Attack.cell_get( i )

  		if ( Attack.act_race( cell ) == "elf"
			 or Attack.act_race( cell ) == "human" )
			 and Attack.act_ally( cell ) then 
   			Attack.multiselect( 0 )

   			return true
  		end 
 	end 

 	return true
end 


function special_encouragement()
	 local power = apply_difficulty_level_talent_bonus( Attack.get_custom_param( "power" ) )
	 local duration = apply_difficulty_level_talent_bonus( Attack.get_custom_param( "duration" ) )
	
  Attack.act_aseq( 0, "cast" )
  local dmgts = Attack.aseq_time( 0, "x" )
 	local ccnt = Attack.cell_count()
 	local count = 0
	
  for i = 0, ccnt - 1 do
    local cell = Attack.cell_get( i )
  	
   	if ( Attack.act_race( cell ) == "elf"
			 or Attack.act_race( cell ) == "human" )
			 and Attack.act_ally( cell ) then 
  	  	local a = Attack.atom_spawn( cell, dmgts, "effect_encouragement", Attack.angleto( cell ) )
  		  Attack.act_del_spell( cell, "special_encouragement" )
    		Attack.act_apply_spell_begin( cell, "special_encouragement", duration, false )
  		  Attack.act_apply_par_spell( "initiative", 0, power, 0, duration, false)
  		  Attack.act_apply_par_spell( "attack", 0, power, 0, duration, false)
  		  Attack.act_apply_spell_end()
  			count = count + 1			
    end
  end

  Attack.resort()

  --	if count==0 then return false end
  return true
end 
